# 🚀 Frontier AI Models Intelligence Hub: The Ultimate LLM Database

### 🌟 Context & Overview
The Generative AI landscape is moving at breakneck speed. Every week, new Large Language Models (LLMs), multimodal foundation models, and open-source challengers are released. Keeping track of **context windows, API pricing, benchmark scores, and architectural capabilities** has become nearly impossible—until now.

The **Frontier AI Models Intelligence Hub** is the world's most comprehensive, continuously updated dataset of modern AI models. Whether you are an AI researcher, a Data Scientist, an MLOps Engineer, or a developer trying to choose the most cost-effective model for your production application, this dataset provides the definitive ground truth.

### 📊 What's Inside?
This dataset offers an unprecedented **130+ columns of rich metadata** across multiple highly-structured relational tables, exported in 9 different formats (CSV, Parquet, JSON, SQLite, etc.) for your convenience. 

We track the absolute latest models—including **GPT-4o, Claude 3.5 Sonnet, Llama 3.1, Gemini 1.5 Pro, Mistral Large**, and hundreds more.

**Key Data Points Include:**
*   **🏗️ Architecture:** Parameter counts, layers, mixture-of-experts (MoE) routing, and active parameters.
*   **🧠 Benchmarks (Knowledge & Coding):** MMLU, GPQA Diamond, MATH, HumanEval, SWE-bench, LiveBench, Chatbot Arena ELO, and more.
*   **👀 Benchmarks (Vision & Multimodal):** MMMU, MathVista, ChartQA, DocVQA, Video-MME.
*   **💸 Pricing & Economics:** Input/Output cost per 1M tokens, cached prompt discounts, batch pricing, and free-tier limits.
*   **⚡ Inference & Performance:** Throughput (tokens/sec), Time-to-First-Token (TTFT), and context window sizes (up to 2M+ tokens).
*   **🔓 Open Source & Licensing:** HuggingFace downloads, commercial usability, open-weights verification, and GitHub stars.

### 💡 Inspiration & Use Cases
This dataset was built to fuel your Kaggle Notebooks and AI research! Here are some ways you can use it:
1.  **Cost-Benefit Analysis:** Build a regression model to predict the "bang for your buck" (Benchmark Score vs. Cost per Token) to find the most efficient models.
2.  **Trend Forecasting:** Analyze the exponential growth of context windows and parameter counts over time. When will 10M token context windows become the norm?
3.  **Open Source vs. Proprietary:** Track the performance gap between open-weights models (like Llama 3) and closed-API models over time.
4.  **RAG Optimization:** Build a recommender system that outputs the perfect LLM based on a user's specific budget, latency requirements, and modality needs.

### 🔄 Update Frequency
This dataset is **Updated Daily** via an automated GitHub Actions pipeline. The pipeline ingests live data from multiple APIs, normalizes the schemas, runs anomaly detection, and pushes the freshest data straight to Kaggle. You will never be working with outdated LLM data again.

### 📚 Provenance & Acknowledgements
This dataset represents a massive aggregation effort. We extend our deepest gratitude to the platforms and organizations that make this data public. Data is aggregated, normalized, and enriched from the following sources:
*   *HuggingFace Hub & Open LLM Leaderboard*
*   *LMSYS Chatbot Arena*
*   *Artificial Analysis*
*   *OpenRouter & Provider APIs (OpenAI, Anthropic, Google, Mistral)*
*   *Papers With Code & Stanford HELM*

### 🤝 Call to Action
If you find this dataset useful for your research, application development, or curiosity, **please leave an Upvote (🔼)**! Your support keeps this project actively maintained and updated every single day.
